<div class="portfolio-modal modal fade" id="privacy_policy" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body">
                            <!-- Project Details Go Here -->
                            <h2>Ansvar</h2>
                            <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                            <p>
                              Mälardalens högskola och Stockholms stad har lag
                              ner mycket tid och arbete på att säkerställa
                              resultatet från räknemallen är korrekt i alla
                              avseenden. Vi kan emellertid inte garantera att
                              det inte förekommer fel. Med hänsyn till att
                              räknemallen tillhandahålls utan kostnad för
                              användaren friskriver sig därför Mälardalens
                              högskola och Stockholm stad, inom ramen för
                              gällande lag, allt ansvar för eventuella förluster
                              som uppstår som en följd av dess användning. All
                              användning av räknemallen sker under eget ansvar.
                            </p>
                            </br></br></br></br></br></br></br></br></br></br>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
